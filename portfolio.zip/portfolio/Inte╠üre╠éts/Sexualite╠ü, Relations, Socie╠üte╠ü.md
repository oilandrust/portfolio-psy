---
thumbnail: media/group.png
id: 6
---
Je suis intéressé par les questions liées aux relations, à la sexualité et à la société. Comment ces questions s'articulent à différents niveaux et sous différents prismes, de la psychologie somatique, de la théorie de l'attachement en passant par l'économie et la psychanalyse.
