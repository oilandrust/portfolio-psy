---
title: 'Polysecure: Attachment, Trauma and Consensual Nonmonogamy'
author: Jessica Fern
id: 11
thumbnail: media/71qhBKcCS1L._AC_UL640_FMwebp_QL65_.webp
---
# Polysecure: Attachment, Trauma and Consensual Nonmonogamy

*Review to be written...*
