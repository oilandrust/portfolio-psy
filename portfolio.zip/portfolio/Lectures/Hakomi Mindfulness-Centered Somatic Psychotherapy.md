---
title: Hakomi Mindfulness-Centered Somatic Psychotherapy
author: Halko Weiss et al.
id: 2
thumbnail: media/41SAbFp7W1L._SY400_.jpg
---
# Hakomi Mindfulness-Centered Somatic Psychotherapy

*Review to be written...*
