---
start_date: "2022-03-01"
end_date: "2022-12-31"
---

# Psychothérapie Focusing et 'Parts Work'
## Premiers essais en psychothérapie

Après avoir complété un certificat en Thérapie Somatique de l'Attachement, j'ai travaillé avec mon premier client 'K'.
Nous avons travaillé ensemble pendant un an et demi de manière régulière et hebdomadaire.
