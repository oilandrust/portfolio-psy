title: Re-connected.fr
subtitle: The wordpress website for my psychotherapy practice
start_date: 2024-09-15
end_date: 2024-01-28
tech: wordpress
image_layout: featured
thumbnail: media/reconnected.png
live_url: https://re-connected.fr

I built my first website using WordPress for my small psychotherapy practice. It is a single page and using the basic WordPress template but it does the job.
This version is the third iteration of the website. I learned to set up a WordPress website and to host it on Amazon Lightsail. I'm interested in learning more about WordPress.
