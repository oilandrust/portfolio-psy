---
title: Olivier's Developer Portfolio
subtitle: Building things fast and slow
thumbnail: profile.jpg
---
Hi, I'm Olivier, I live in Strasbourg, France, and before I lived around Europe in Germany and Sweden. I worked as a developer for 10 years, with a specialisation on C++, Graphics Programming and Game Development. Notably I worked for Massive Entertainment, a Ubisoft Studio. I also worked with web and built mobile applications. This page showcases some personal projects and work experiences.

Right now I study Psychology to become a Psychotherapist, but I might be able to contribute to some projects. I am interested in building small tools and applications to make the life of small businesses easier. Feel free to get in touch if you have some curiosity.
